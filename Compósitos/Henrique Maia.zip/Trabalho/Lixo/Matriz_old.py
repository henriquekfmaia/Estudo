class Matriz: ## Define o que e uma matriz
    def __init__(self, matriz): ## Roda ao criar a matriz
        self = matriz ## Matriz
        ##self.matriz = matriz ## Matriz
        self.check() ## Verifica se a matriz esta correta
        
    def check(self): ## Funcao que verifica se a matriz esta correta
        for line in self.matriz: # Para cada linha da matriz
            if len(line) == len(self.matriz[0]): ## Verifica se a linha tem o mesmo numero de elementos que a primeira linha
                return True
            else:
                print('fodeo') #####################################
                return ## Deve retornar um erro

    def print(self): ## Funcao para printar matriz
        for line in self.matriz: ## Printa linha por linha
            print(line)

    def trans(self): ## Funcao que retorna matriz transposta
        trans = [] ## Cria uma lista que posteriormente sera transformada na matriz
        for column in range(0,len(self.matriz[0])): ## Para cada coluna c na matriz original
            trans.append([]) ## Adiciona uma linha a lista 'trans'
            for line in range(0,len(self.matriz)): ## Para cada linha l na matriz original
                trans[column].append(self.matriz[line][column]) ## Transforma essa linha l da matriz original na coluna c da matriz transposta
        return Matriz(trans) ## Retorna matriz transposta

    def inv(self,method='GJ'):
        if method.upper() == 'GJ':
            self.inv_GJ()
        else:
            pass

    def inv_GJ(self): ## Inverte a matriz pelo metodo Gauss-Jordan
        ident = [] ## Esta lista se tornara a matriz identidade
        copy = [] ## Essa matriz ira copiar a matriz que sera invertida
        for i in range(0,len(self.matriz)): ## Vamos contruir as matrizes copy e ident
            ident.append([]) ## Adiciona uma linha a matriz
            copy.append([]) ## Adiciona uma linha a matriz
            for j in range(0,len(self.matriz[0])):
                copy[i].append(self.matriz[i][j]) ## Copia o termo ij da matriz que sera invertida para a copia
                if i == j: ## Se i = j
                    ident[i].append(1) ## Adiciona o termo 1 ao espaço ij da matriz
                else: ## Se i =! j
                    ident[i].append(0) ## Adiciona o termo 0 ao espaço ij da matriz
        ident = Matriz(ident) ## Transforma as listas em matrizes
        copy = Matriz(copy) ## Vamos agora aplicar o metodo Gauss-Jordan
        ## O primeiro passo e fazer com que todos os elementos da matriz fora da diagonal principal se tornem zeros
        for line in range(0,len(copy)): ## Cada linha rodara a iteracao uma vez
            for i in range(0,len(copy)): ## Em todas as outras linhas
                if copy[i] != copy[line]: ## Somente as OUTRAS linhas (nao ela mesma)
                    f = copy[i][line]/copy[line][line]## Obtem o fator de multiplicacao entre a linha principal e a linha 'alvo'
                    for j in range(0,len(copy[0])):
                        copy[i][j] = copy[i][j] - f*copy[line][j] ## Li = Li - f*Lline
                        ident[i][j] = ident[i][j] - f*copy[line][j]
        ident.print()
        copy.print()
            

def msum(l):
    try:
        for matriz in l: ## Para cada matriz na lista
            if len(matriz.matriz) == len(l[0].matriz) and len(matriz.matriz[0]) == len(l[0].matriz[0]): ## Verifica se as matrizes sao do mesmo tamanho da primeira matriz
                pass
            else:
                raise NameError ## Caso contrario a funcao para
        ## Agora comecamos a soma das matrizes
        msum = [] ## Cria uma lista vazia que ira armazenar a soma, que posteriormente sera transformado na matriz resultante
        for line in range(0,len(l[0].matriz)): ## Para cada linha
            msum.append([]) ## Adiciona uma linha a matriz da soma
            for column in range(0,len(l[0].matriz[0])): ## Para cada linha
                s = 0 ## Zera o valor de s (que corresponde a soma dos termos ij das matrizes
                for i in l: ## Para cada matriz que esta sendo somada
                    s = s + i.matriz[line][column] ## Adiciona-se a s o termo ij de cada matriz
                msum[line].append(s) ## Adiciona-se a soma dos termos de indice ij ao espaço ij da matriz resultante
        return Matriz(msum)  ## Retorna a matriz da soma
    except:
        pass
            
def mult(A, B): ## Produto matriz x matriz, matriz x escalar e escalar x matriz
    try:
        if A.check() == True and B.check() == True: ## Produto matriz x matriz
            if len(A.matriz[0]) == len(B.matriz): ## Verifica se o numero de linhas de colunas de A e igual ao numero de linhas de B
                prod = [] ## Cria uma lista vazia que ira armazenar o produto, que posteriormente sera transformado na matriz resultante
                for i in range(0,len(A.matriz)): ## Para cada linha i na matriz A
                    prod.append([]) ## Cria-se uma linha na matriz produto
                    for j in range(0,len(B.matriz[0])): ## Para cada coluna na matriz B
                        n = 0 ## Começa a calcular o valor do elemento ij da matriz produto
                        for c in range(0,len(A.matriz[0])): ## Cria-se a variavel c, que corre da primeira a ultima linha em A/coluna em B
                            n = n + A.matriz[i][c]*B.matriz[c][j] ## Soma-se a n o produto entre o elemento de A com indice ic e o elemento de B com indice cj
                        prod[i].append(n) ## Adiciona o elemento de indice ij a matriz do produto
            return Matriz(prod) ## Retorna a matriz do produto
    except:
        pass

    try:
        if A.check() == True and type(B) == type(int(1)) or A.check() == True and type(B) == type(float(1)): ## Produto matriz x escalar
            prod = [] ## Cria uma lista vazia que ira armazenar o produto, que posteriormente sera transformado na matriz resultante
            for line in range(0,len(A.matriz)): ## Para cada linha na matriz A
                prod.append([]) ## Adiciona uma linha a matriz do produto
                for column in range(0,len(A.matriz[0])): ## Para cada coluna da matriz A
                    prod[line].append(B*A.matriz[line][column]) ## Multiplica-se o elemento da linha/coluna de A pelo escalar B
            return Matriz(prod) ## Retorna a matriz do produto
    except:
        pass

    try:
        if B.check() == True and type(A) == type(int(1)) or B.check() == True and type(A) == type(float(1)): ## Produto escalar x matriz
            prod = [] ## Cria uma lista vazia que ira armazenar o produto, que posteriormente sera transformado na matriz resultante
            for line in range(0,len(B.matriz)): ## Para cada linha na matriz B
                prod.append([]) ## Adiciona uma linha a matriz do produto
                for column in range(0,len(B.matriz[0])): ## Para cada coluna da matriz B
                    prod[line].append(A*B.matriz[line][column]) ## Multiplica-se o elemento da linha/coluna de B pelo escalar A
            return Matriz(prod) ## Retorna a matriz do produto
    except:
        pass
    



    
#A = Matriz([[1, 1, 1],
            #[2, 4, 6],
            #[2, 2, 2]])
#B = float(1)

#B = Matriz([[1, 1, 1],
            #[0, 0, 0],
            #[0, 2, 3]])

C = Matriz([[2, 1],
            [4, 3]])


C.inv()
