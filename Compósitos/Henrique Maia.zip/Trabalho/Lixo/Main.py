import Solve as s
import Plot as p
import Report as r

Pmax = s.solve()


